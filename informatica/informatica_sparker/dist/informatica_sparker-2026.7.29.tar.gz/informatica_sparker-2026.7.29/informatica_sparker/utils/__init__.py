# SQL dialect utilities
